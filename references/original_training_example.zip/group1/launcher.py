from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    while True:
        print('\n1 — обучить и сохранить модель')
        print('2 — обработать один файл')
        print('3 — запустить проверочные файлы')
        print('0 — выйти')
        choice = input('Действие: ').strip()
        if choice == '0':
            return
        if choice == '1':
            command = [sys.executable, 'train.py']
        elif choice == '2':
            path = input('Путь к файлу: ').strip().strip('"')
            command = [sys.executable, 'predict.py', path]
            if (ROOT / 'data/history.csv').exists():
                at = input('Момент решения, например 2026-10-29T12:00:00: ').strip()
                command += ['--at', at]
        elif choice == '3':
            command = [sys.executable, 'run_cases.py']
        else:
            continue
        subprocess.run(command, cwd=ROOT)


if __name__ == '__main__':
    main()
