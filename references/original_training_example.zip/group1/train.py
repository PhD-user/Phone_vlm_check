import json
from datetime import datetime
import joblib
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, recall_score
from common import ROOT, IMAGE_SIZE, load_features


def main():
    if (ROOT / 'artifacts/model.joblib').exists():
        raise SystemExit('Модель уже сохранена. Для нового обучения укажите другую папку artifacts в train.py.')
    train = pd.read_csv(ROOT / 'data/train.csv')
    validation = pd.read_csv(ROOT / 'data/validation.csv')
    model = RandomForestClassifier(n_estimators=120, max_depth=12,
                                   min_samples_leaf=2, random_state=42, n_jobs=-1)
    model.fit(load_features(train['path']), train['label'])
    prediction = model.predict(load_features(validation['path']))
    folder = ROOT / 'artifacts'
    folder.mkdir(exist_ok=True)
    model_path = folder / 'model.joblib'
    joblib.dump({'model': model, 'image_size': IMAGE_SIZE,
                 'sklearn_version': sklearn.__version__, 'seed': 42,
                 'trained_at': datetime.now().isoformat()}, model_path)
    metrics = {'accuracy': float(accuracy_score(validation['label'], prediction)),
               'recall_foreign': float(recall_score(validation['label'], prediction, pos_label='foreign')),
               'validation_count': len(validation),
               'matrix_labels': ['own', 'foreign'],
               'confusion_matrix': confusion_matrix(validation['label'], prediction,
                                                    labels=['own', 'foreign']).tolist()}
    (folder / 'training_metrics.json').write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding='utf-8')
    validation.assign(prediction=prediction).to_csv(folder / 'validation_predictions.csv', index=False)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    print('Модель сохранена:', model_path)


if __name__ == '__main__':
    main()
