import argparse
import json
import sys
import joblib
import sklearn
from PIL import Image, UnidentifiedImageError
from common import ROOT, IMAGE_SIZE, image_features, image_info
from checks import check_image


def predict(path):
    bundle = joblib.load(ROOT / 'artifacts/model.joblib')
    if bundle['sklearn_version'] != sklearn.__version__:
        raise ValueError('Версия scikit-learn отличается от версии обучения.')
    if tuple(bundle['image_size']) != IMAGE_SIZE:
        raise ValueError('Подготовка изображения отличается от использованной при обучении.')
    with Image.open(path) as image:
        image.load()
        info = image_info(image)
        reasons = check_image(info)
        if reasons:
            return {'status': 'refused', 'reasons': reasons, 'input': str(path), 'image': info}
        values = image_features(image)[None, :]
    model = bundle['model']
    label = str(model.predict(values)[0])
    return {'status': 'ok', 'label': label,
            'answer': {'own': 'свой', 'foreign': 'чужой'}[label],
            'input': str(path), 'image': info}


def main():
    parser = argparse.ArgumentParser(description='Распознавание одного изображения без обучения.')
    parser.add_argument('image', help='Путь к изображению')
    args = parser.parse_args()
    try:
        result = predict(args.image)
    except FileNotFoundError as exc:
        result = {'status': 'error', 'message': 'Файл не найден: ' + str(exc.filename)}
    except (UnidentifiedImageError, OSError):
        result = {'status': 'error', 'message': 'Не удалось прочитать изображение.'}
    except (ValueError, KeyError) as exc:
        result = {'status': 'error', 'message': str(exc)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'ok' else 2


if __name__ == '__main__':
    sys.exit(main())
