@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
set "LAB_PY="
for %%V in (3.12 3.13 3.11) do (
  if not defined LAB_PY (
    py -%%V -c "import sys" >nul 2>&1
    if not errorlevel 1 set "LAB_PY=%%V"
  )
)
if not defined LAB_PY (
  echo Нужен Python 3.11, 3.12 или 3.13 с командой py.
  goto fail
)
py -%LAB_PY% -m venv .venv
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
echo Установка завершена. Откройте ЗАПУСК.bat
pause
exit /b 0
:fail
echo Установка не завершена. Проверьте Python и подключение к сети.
pause
exit /b 1
