"""Заготовка обработки папки. Один неподходящий файл не должен останавливать остальные."""
import argparse
from pathlib import Path


def process_folder(folder, output):
    # Задание: переберите файлы папки, получите ответ для каждого,
    # сохраните filename, status, answer, reason в CSV.
    # Ошибку чтения отдельного файла нужно записать в его строку.
    # Можно импортировать predict из predict.py.
    # Тело функции заполните сами. Подробные требования есть в методичке.
    return False


def main():
    parser = argparse.ArgumentParser(description='Обработка папки изображений.')
    parser.add_argument('folder', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    if not args.folder.is_dir():
        parser.error('Папка не найдена.')
    if args.output.exists():
        parser.error('Выходной файл уже существует. Укажите новое имя.')
    if process_folder(args.folder, args.output) is False:
        print('Обработка папки ещё не написана. Допишите process_folder в batch.py.')
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
