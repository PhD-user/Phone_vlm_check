from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
IMAGE_SIZE = (20, 20)


def image_features(image):
    """Одинаковая подготовка при обучении и применении."""
    rgb = image.convert('RGB').resize(IMAGE_SIZE)
    return np.asarray(rgb, dtype=np.float32).reshape(-1) / 255.0


def load_features(paths):
    rows = []
    for path in paths:
        with Image.open(ROOT / path) as image:
            rows.append(image_features(image))
    return np.asarray(rows)


def image_info(image):
    gray = np.asarray(image.convert('L'), dtype=float)
    edges = np.abs(np.diff(gray, axis=0)).mean() if gray.shape[0] > 1 else 0
    return {
        'width': image.width,
        'height': image.height,
        'brightness': round(float(gray.mean()), 2),
        'contrast': round(float(gray.std()), 2),
        'edge_difference': round(float(edges), 2),
    }
