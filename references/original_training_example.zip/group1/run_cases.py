"""Запускает predict.py для проверочных файлов и сохраняет фактические ответы."""
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime
from uuid import uuid4

ROOT = Path(__file__).resolve().parent


def main():
    cases = json.loads((ROOT / 'inputs/cases.json').read_text(encoding='utf-8'))
    folder = ROOT / 'results' / (datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:6])
    folder.mkdir(parents=True)
    rows = []
    for case in cases:
        command = [sys.executable, str(ROOT / 'predict.py'), str(ROOT / case['file'])]
        if 'at' in case:
            command += ['--at', case['at']]
        env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONUTF8='1')
        completed = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True,
                                   encoding='utf-8', errors='replace', timeout=45)
        (folder / (case['id']+'.txt')).write_text(completed.stdout+'\n'+completed.stderr, encoding='utf-8')
        try:
            result = json.loads(completed.stdout)
        except json.JSONDecodeError:
            result = {'status': 'crash', 'message': completed.stderr[-500:]}
        expected = case['expected'].split('|')
        status = result.get('status', 'unknown')
        rows.append({'case': case['id'], 'file': case['file'], 'expected_status': case['expected'],
                     'actual_status': status, 'status_matches': status in expected,
                     'answer': result.get('answer', result.get('choice', '')),
                     'reason': '; '.join(result.get('reasons', [])) or result.get('message', ''),
                     'exit_code': completed.returncode})
        print(f"{case['id']}: {status}; ожидается {case['expected']}")
    with (folder / 'results.csv').open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    print('Результаты:', folder)
    print('Совпадение статуса не проверяет правильность класса, прогноза или объяснения отказа.')


if __name__ == '__main__':
    main()
